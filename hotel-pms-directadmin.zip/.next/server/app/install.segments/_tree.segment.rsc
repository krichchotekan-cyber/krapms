:HL["/_next/static/chunks/2rm5eyx6n_qt7.css","style"]
2:[["children",{"s":"__PAGE__","h":49314}]]
1:[["children",{"s":"install","h":49250,"c":"$Q2"}]]
0:{"b":"f1Fht1SnIQU-egz1GQ476","t":{"t":{"s":"","h":49234,"c":"$Q1"}}}
