var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/webhooks/ota/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/[root-of-the-server]__1r7kbfkiw2xmu._.js")
R.c("server/chunks/_1j0x02-3y3nx9._.js")
R.c("server/chunks/_next-internal_server_app_api_webhooks_ota_route_actions_1hwn8x5w3xcfo.js")
R.m(86427)
module.exports=R.m(86427).exports
