var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send-folio-email/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/[root-of-the-server]__1r7kbfkiw2xmu._.js")
R.c("server/chunks/_1cg5xytlp_w3f._.js")
R.c("server/chunks/_next-internal_server_app_api_send-folio-email_route_actions_0_-d-pft6ktt2.js")
R.m(79725)
module.exports=R.m(79725).exports
