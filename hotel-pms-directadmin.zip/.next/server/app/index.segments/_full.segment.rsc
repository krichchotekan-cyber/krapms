1:"$Sreact.fragment"
2:"/_next/static/chunks/1tq6ppe__m8m-.js"
3:I[39756,["$2"],"default"]
4:I[37457,["$2"],"default"]
7:I[47257,["$2"],"ClientPageRoot"]
8:"/_next/static/chunks/2ngejtej0k708.js"
9:"/_next/static/chunks/0exg8wnczjk2g.js"
a:I[52683,["$2","$8","$9"],"default"]
b:I[97367,["$2"],"OutletBoundary"]
c:"$Sreact.suspense"
f:"ViewportBoundary"
10:I[97367,["$2"],"$f"]
12:"MetadataBoundary"
13:I[97367,["$2"],"$12"]
16:I[68027,["$2"],"default",1]
:HL["/_next/static/chunks/2rm5eyx6n_qt7.css","style"]
5:X
e:X
6:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":[["$","$L7",null,{"Component":"$a","serverProvidedParams":null}],[["$","script","script-0",{"src":"/_next/static/chunks/2ngejtej0k708.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/0exg8wnczjk2g.js","async":true,"nonce":"$undefined"}]],["$","$Lb",null,{"children":["$","$c",null,{"name":"Next.MetadataOutlet","children":"$@d"}]}]]}],"p":true,"v":"$e"}}]]
15:X
17:X
18:X
0:{"P":null,"c":["",""],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/2rm5eyx6n_qt7.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/1tq6ppe__m8m-.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"th","suppressHydrationWarning":true,"className":"h-full antialiased","children":[["$","head",null,{"children":["$","script",null,{"dangerouslySetInnerHTML":{"__html":"\n              if (typeof window !== \"undefined\" && \"serviceWorker\" in navigator) {\n                navigator.serviceWorker.getRegistrations().then(function(registrations) {\n                  for (var i = 0; i < registrations.length; i++) {\n                    registrations[i].unregister();\n                  }\n                });\n              }\n            "}}]}],["$","body",null,{"className":"min-h-full flex flex-col","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]]}]]}],"p":true,"v":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[null,["$","$L10",null,{"children":"$L11"}],["$","$L13",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$c",null,{"name":"Next.Metadata","children":"$L14"}]}],null]}],null]}],"p":true,"v":"$15"}},"m":"$undefined","G":["$16",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/2rm5eyx6n_qt7.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$17","s":"$18","a":"$@19","l":"$undefined","p":"$undefined","d":"$undefined","b":"f1Fht1SnIQU-egz1GQ476","u":"$@1a"}
e:C
18:300
11:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
1b:I[27201,["$2"],"IconMark"]
d:null
14:[["$","title","0",{"children":"KRA Hotel PMS - Bu-Gaan & Thanawong"}],["$","meta","1",{"name":"description","content":"ระบบบริหารจัดการโรงแรม Multi-Property (Bu-Gaan Sukhothai Village & Thanawong Pool Villa)"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L1b","3",{}]]
18:C
15:C
17:C
5:C
1a:false
19:null
