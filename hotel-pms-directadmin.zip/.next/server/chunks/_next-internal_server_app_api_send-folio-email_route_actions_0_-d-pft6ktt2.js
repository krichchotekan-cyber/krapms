module.exports=[66402,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_send-folio-email_route_actions_0_-d-pft6ktt2.js.map