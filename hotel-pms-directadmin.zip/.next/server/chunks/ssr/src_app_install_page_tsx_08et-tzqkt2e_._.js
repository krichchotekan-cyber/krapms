module.exports=[64022,a=>{"use strict";var b=a.i(87924),c=a.i(11467),d=a.i(6070);a.s(["default",0,function(){return(0,b.jsx)(c.a,{children:(0,b.jsx)(d.f,{isOpen:!0,isStandalonePage:!0})})}])}];

//# sourceMappingURL=src_app_install_page_tsx_08et-tzqkt2e_._.js.map