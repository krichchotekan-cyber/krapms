module.exports=[5953,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_webhooks_ota_route_actions_1hwn8x5w3xcfo.js.map